/**
 * Paysi — preset Tailwind v1.0
 * Uso:  module.exports = { presets: [require('./paysi.tailwind.preset')], ... }
 */
module.exports = {
  theme: {
    extend: {
      colors: {
        paysi: {
          DEFAULT: '#1D6BD8',
          pressionado: '#1858B4',
          secundaria: '#7FAFEE',
          texto: '#14181F',
          'texto-secundario': '#5C6472',
          linha: '#E6E9EF',
          'fundo-suave': '#F7F9FC',
        },
        azul: {
          50: '#F0F5FD', 100: '#DCE8FA', 200: '#BBD2F6', 300: '#7FAFEE',
          400: '#4A8AE3', 500: '#1D6BD8', 600: '#1858B4', 700: '#144890',
          800: '#12386C', 900: '#0F2A4E',
        },
        neutra: {
          0: '#FFFFFF', 25: '#F7F9FC', 50: '#F1F4F9', 100: '#E6E9EF',
          200: '#D3D8E2', 300: '#B4BCCA', 400: '#8B94A5', 500: '#5C6472',
          600: '#474E5C', 700: '#343A46', 800: '#23282F', 900: '#14181F',
        },
        sucesso: { DEFAULT: '#067A55', superficie: '#E8F6F0' },
        atencao: { DEFAULT: '#8A5A00', superficie: '#FCF3E3' },
        erro: { DEFAULT: '#C0362E', superficie: '#FDEDEB' },
        info: { DEFAULT: '#1858B4', superficie: '#EAF1FC' },
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', '-apple-system', 'BlinkMacSystemFont',
               'SF Pro Display', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
        valor: ['Inter', 'SF Mono', 'ui-monospace', 'JetBrains Mono',
                'Menlo', 'Consolas', 'monospace'],
      },
      fontSize: {
        display: ['3rem',     { lineHeight: '1.1',  letterSpacing: '-0.02em',  fontWeight: '700' }],
        h1:      ['2rem',     { lineHeight: '1.2',  letterSpacing: '-0.015em', fontWeight: '600' }],
        h2:      ['1.5rem',   { lineHeight: '1.3',  letterSpacing: '-0.01em',  fontWeight: '600' }],
        h3:      ['1.25rem',  { lineHeight: '1.4',                             fontWeight: '600' }],
        'corpo-g': ['1.125rem', { lineHeight: '1.6' }],
        corpo:   ['1rem',     { lineHeight: '1.5' }],
        apoio:   ['0.875rem', { lineHeight: '1.5' }],
        legenda: ['0.75rem',  { lineHeight: '1.4',                             fontWeight: '500' }],
        rotulo:  ['0.75rem',  { lineHeight: '1.2',  letterSpacing: '0.08em',   fontWeight: '600' }],
      },
      borderRadius: {
        xs: '4px', sm: '8px', md: '12px', lg: '16px', xl: '24px', total: '999px',
      },
      boxShadow: {
        sm: '0 1px 2px rgba(20,24,31,0.06)',
        md: '0 2px 8px rgba(20,24,31,0.08)',
        lg: '0 8px 24px rgba(20,24,31,0.10)',
        xl: '0 16px 48px rgba(20,24,31,0.12)',
        foco: '0 0 0 3px rgba(29,107,216,0.32)',
      },
      transitionTimingFunction: {
        padrao: 'cubic-bezier(0.2,0,0.2,1)',
        entrada: 'cubic-bezier(0,0,0.2,1)',
        saida: 'cubic-bezier(0.4,0,1,1)',
      },
      transitionDuration: { rapida: '120ms', padrao: '200ms', lenta: '320ms' },
    },
  },
};
