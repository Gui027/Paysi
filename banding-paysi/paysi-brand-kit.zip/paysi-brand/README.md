# Paysi — Kit de Marca v1.0

Documentação e arquivos da identidade visual Paysi, a partir da arte *"Paysi — Identidade Visual"* (direção aprovada).

## Por onde começar

| Se você é… | Abra |
|---|---|
| Designer, marketing, agência | **`paysi-brandbook.html`** — manual visual navegável, abre no navegador, arquivo único |
| Quem vai aplicar a marca | **`MANUAL-IDENTIDADE-PAYSI.md`** — manual completo, com todas as regras |
| Desenvolvedor front-end | **`tokens/paysi-tokens.css`** — variáveis prontas, tema claro e escuro |
| Quem precisa só do logo | **`assets/`** (vetor) ou **`assets/png/`** (bitmap) |

## Estrutura

```
paysi-brand/
├── README.md
├── MANUAL-IDENTIDADE-PAYSI.md          manual completo
├── paysi-brandbook.html                manual visual, arquivo único
├── assets/
│   ├── paysi-logo-horizontal.svg       assinatura principal
│   ├── paysi-logo-horizontal-negativo.svg
│   ├── paysi-logo-horizontal-mono.svg  1 cor, usa currentColor
│   ├── paysi-logo-vertical.svg
│   ├── paysi-logotipo.svg              só a palavra
│   ├── paysi-simbolo.svg
│   ├── paysi-simbolo-currentcolor.svg
│   ├── paysi-app-icon.svg              fundo branco
│   ├── paysi-app-icon-azul.svg         fundo azul
│   ├── paysi-favicon.svg
│   └── png/                            exports 1x/2x/3x, ícones 128→1024, favicon.ico
└── tokens/
    ├── paysi-tokens.css                variáveis CSS
    ├── paysi-tokens.json               W3C Design Tokens (Style Dictionary, Tokens Studio)
    └── paysi.tailwind.preset.js         preset Tailwind
```

## Uso rápido

**CSS**

```html
<link rel="stylesheet" href="tokens/paysi-tokens.css">
```
```css
.botao { background: var(--acao-primaria); color: var(--texto-sobre-primaria);
         border-radius: var(--raio-md); font: 600 .9375rem/1 var(--fonte-marca); }
```

Tema escuro: `<html data-tema="escuro">`.

**Tailwind**

```js
module.exports = { presets: [require('./tokens/paysi.tailwind.preset')] };
```

**Favicon**

```html
<link rel="icon" href="/assets/paysi-favicon.svg" type="image/svg+xml">
<link rel="icon" href="/assets/png/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/assets/png/paysi-app-icon-180.png">
```

**Símbolo em componente React**

```jsx
import Simbolo from './assets/paysi-simbolo-currentcolor.svg';
// herda a cor do elemento pai — use color: var(--paysi-primaria)
```

## Três coisas que costumam dar errado

1. **Não redigite “Paysi”.** O logotipo está em curvas dentro do SVG. Escrever com fonte de sistema não bate com a marca.
2. **`#7FAFEE` não recebe texto sobre fundo claro** — 2,27:1, reprovado em acessibilidade. Ela é para preenchimento e para brilhar sobre fundo escuro.
3. **Abaixo de 96 px de largura, use o símbolo isolado.** A assinatura horizontal fecha e vira mancha.

## Sobre os vetores

Reconstruídos em curvas a partir da arte aprovada. O logotipo está convertido em contornos (Inter Display Bold, licença SIL OFL) — não depende de fonte instalada. O símbolo é um único `path` com `fill-rule="evenodd"`: display e teclas são furos transparentes, não formas brancas, então funciona sobre qualquer fundo.

---

*Paysi — Pagamentos inteligentes para o seu negócio.*
